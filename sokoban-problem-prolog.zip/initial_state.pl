top(l7,l4).
top(l4,l1).
top(l8,l5).
top(l5,l2).
top(l9,l6).
top(l6,l3).
right(l1,l2).
right(l2,l3).
right(l4,l5).
right(l5,l6).
right(l7,l8).
right(l8,l9).

box(l5).
box(l6).

solution(l8).
solution(l9).

sokoban(l7).

initial_state(state(l7, [l5, l6])).